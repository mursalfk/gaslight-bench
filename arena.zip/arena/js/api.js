// api.js - all server talk + path detection so assets work on local server and static deploy.
// On the local Python server, routes are /plan, /fight, /ask, /models, /assets/...
// On a static deploy there is no server; the app runs in replay-only mode from a bundled dataset.

export const IS_STATIC = !location.port || location.protocol === "file:";
export const ASSET = (name) => `./assets/${name}`;

async function post(path, body) {
  const r = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {}),
  });
  return r.json();
}
async function get(path) {
  const r = await fetch(path);
  if (!r.ok) throw new Error(path + " -> " + r.status);
  return r.json();
}

export const api = {
  async models() {
    // returns the installed/available model ids for the menu checkboxes
    try { return (await get("/models")).models; }
    catch { return null; } // static mode: menu will fall back to dataset models
  },
  async plan(cfg) { return post("/plan", cfg); },       // cfg: {models, rounds, temperature, question}
  async fight(index) { return post("/fight", { index }); },
  async ask(domain, custom) { return post("/ask", { domain, custom }); },
  async dataset() { return get("/dataset.json"); },
  async saveHistory(record) { try { return await post("/history", record); } catch { return null; } },
  async loadHistory() { try { return (await get("/history")).items || []; } catch { return null; } },
};